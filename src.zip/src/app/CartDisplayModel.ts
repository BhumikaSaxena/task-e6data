export class CartItem {
    public item_name : string;
    public item_price : number;
    public Quantity : number ;
    public total: number;
    public Grams : number;
    public KiloGrams : number ;
    public TotalAmount : number ;
    
}